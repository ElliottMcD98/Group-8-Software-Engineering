# Group-8-Software-Engineering

<h3>Members:</h3>
17643101 - Callum Dyson-Gainsborough </br>
15616382 - Elliott Mcdonald </br>
16634291 - Luke Powell </br>
17666296 - Shiyan Li </br>

<h3>Trello:</h3>
https://trello.com/b/XQuhCfT1/group-8-software-engineering


